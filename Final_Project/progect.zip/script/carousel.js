$('.carousel-item').slick({
    arrow:false,
    dots: true,
    autoplay: true,
    autoplaySpeed: 4000,
})